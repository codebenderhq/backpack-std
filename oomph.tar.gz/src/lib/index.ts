import "./error.ts";
export { db, get_kv } from "./persistence.ts";

console.log("observabilty loaded into app");
