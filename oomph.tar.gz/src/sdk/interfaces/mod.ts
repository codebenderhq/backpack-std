// Copyright 2022-2023 codebenderhq. All rights reserved. MIT license.
import { oomph_db } from "./db.ts";

/** The oomph SDK. */
export declare namespace oomph {
  declare interface db {}
  oomph_db;
  declare interface web {}

  /**
   * Returns the implementation of oomph db
   *
   * ```js
   * // initalize db
   * const db = oomph.db('user')
   *
   * db.data = {
   * name: "Rawk Akani"
   * }
   * ```
   *
   * Requires `--unstable` permission.
   *
   * @tags unstable
   * @category database
   * @return {oomph_db} oomph_db
   */
  export function db(): oomph_db;
}
