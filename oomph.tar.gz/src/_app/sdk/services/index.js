import { doc } from "https://deno.land/x/deno_doc/mod.ts";

export default (props) => {
};

export const onServer = async (path, req) => {
  const something = new URL("../../../sdk/interfaces/mod.ts", import.meta.url)
    .toString();
  const db = new URL("../../../sdk/interfaces/db.ts", import.meta.url)
    .toString();
  const colorsDoc = await doc(something);
  //  console.log(colorsDoc)
  const dbDoc = await doc(
    colorsDoc.filter((doc) => doc.name === "oomph_db")[0].importDef.src,
  );

  //    console.log(colorsDoc.filter(doc => doc.declarationKind === "export"));
  console.log(dbDoc);
  //console.log(dbDoc);

  return {};
};
